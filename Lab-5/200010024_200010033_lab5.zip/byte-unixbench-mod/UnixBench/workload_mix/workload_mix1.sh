#!/bin/sh
./arithoh.sh &
./arithoh.sh &
./fstime.sh &
./pipe.sh &
./syscall.sh &
wait
