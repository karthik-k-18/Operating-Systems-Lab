#!/bin/sh
time ../pgms/arithoh
echo "arithoh completed"
echo "---"
